local version = 0.23


local champ = myHero.charName
local AiOPath = "14AiO\\"
local lua = "14" .. champ

local function ReadFile(path, fileName)
    local file = io.open(path .. fileName, "r")
    local result = file:read()
    file:close()
    return result
end

local SupportChampion = {
    ["Lulu"] 	    = 	    true,
    ["Sivir"] 	    = 	    true,
    ["Khazix"] 	    = 	    true,
    ["Brand"] 	    = 	    true,
    ["Amumu"] 	    = 	    true,
    ["Nautilus"]    = 	    true,
    ["Morgana"]     =       true,
    ["Blitzcrank"]  =       true,
    ["Vi"]          =       true,
    ["Zilean"]      =       true,
    ["Yasuo"]       =       true,
    ["Orianna"]     =       true,
    ["Leona"]       =       true,
    ["Senna"]       =       true,
    ["Thresh"]      =       true,
    ["Ryze"]        =       true,
    ["Kaisa"]       =       true,
    ["Kayle"]       =       true,
    ["Vayne"]       =       true,
    ["Kindred"]     =       true,
    ["Graves"]      =       true,
    ["Jax"]         =       true,
    ["Tristana"]    =       true,
    ["Ashe"]        =       true,
    ["Garen"]       =       true,
    ["Pantheon"]    =       true,
    ["Tryndamere"]  =       true,
    ["Kennen"]      =       true,
    ["Talon"]       =       true
    

}



if SupportChampion[champ] then

    local beginText = ReadFile(COMMON_PATH .. AiOPath, "Begin.lua")
    local championText = ReadFile(COMMON_PATH .. AiOPath, lua..".lua")
    local endText = ReadFile(COMMON_PATH .. AiOPath, "End.lua")
    local out = beginText..championText..endText

    local func = loadstring(out)

    Callback.Add("Load", function() 
        func()
    end)

else
    print(champ.. " Not supported in 14AIO")
end

-- Callback.Add("Load", function() 
--     require(AiOPath.."source\\" .. lua)
-- end)