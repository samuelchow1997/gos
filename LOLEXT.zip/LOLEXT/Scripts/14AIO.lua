local version = 0.23


local champ = myHero.charName
local AiOPath = "14AiO\\"
local lua = "14" .. champ

local SupportChampion = {
    ["Lulu"] 	    = 		true,
    ["Sivir"] 	    = 		true,    
    ["Khazix"] 	    = 		true,
    ["Brand"] 	    = 		true,
    ["Amumu"] 	    = 		true,
    ["Nautilus"]    = 	    true,
    ["Morgana"]     =       true,
    ["Blitzcrank"]  =       true,
    ["Vi"]          =       true,
    ["Zilean"]      =       true,
    ["Yasuo"]       =       true,
    ["Orianna"]     =       true,
    ["Leona"]       =       true,
    ["Senna"]       =       true,
    ["Thresh"]      =       true,
    ["Ryze"]        =       true,
    ["Kaisa"]       =       true,
    ["Kayle"]       =       true,
    ["Vayne"]       =       true,
    ["Kindred"]     =       true

}



if SupportChampion[champ] then

    Callback.Add("Load", function() 
        require(AiOPath .. lua)
    end)

else
    print(champ.. " Not supported in 14AIO")
end